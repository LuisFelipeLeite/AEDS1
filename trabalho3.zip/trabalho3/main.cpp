/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author:  Luís Felipe Barbosa Leite 2024.1.08.018
 *
 * Created on 2 de abril de 2024, 17:01
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    float lado, lado1, lado2, lado3, raio, altura, area, volume, geratriz;
    string objeto; 
    
    
    ifstream arquivo("entrada.txt");
     if(!arquivo.is_open()){
         cout<<"Erro: arquivo não existe."<<endl;
         return 1;
        }
    
    arquivo >> objeto; 
   
    
    while(objeto != "Fim"){
        if (objeto == "Cubo"){
            arquivo >> lado;
            area = lado*lado*6;
            volume = lado*lado*lado;
            
            cout <<objeto<<endl;
            cout<<"Área:"<<area<<endl;
            cout<<"Volume:"<<volume<<endl;
        } else 
            if(objeto == "Esfera"){
                arquivo >> raio;
                area = 4*3.14*raio*raio;
                volume = 4*3.14*raio*raio*raio/3;
                
                cout <<objeto<<endl;
                cout<<"Área:"<<area<<endl;
                cout<<"Volume:"<<volume<<endl;
            }else
                if(objeto == "Quadrado"){
                    arquivo >> lado;
                    area = lado*lado;
                    
                    cout <<objeto<<endl;
                    cout<<"Área:"<<area<<endl;
                }else
                    if(objeto == "Circulo"){
                        arquivo >> raio;
                        area= 3.14*raio*raio;
                        
                        cout <<objeto<<endl;
                        cout <<"Área:"<<area<<endl;
                    }else
                        if(objeto == "Retângulo"){
                            arquivo >> lado1;
                            arquivo >> lado2;
                            area = lado1*lado2;
                            
                            cout <<objeto<<endl;
                            cout <<"Área:"<<area<<endl;
                        }else 
                            if(objeto == "Paralelepípedo"){
                                arquivo >> lado1;
                                arquivo >> lado2;
                                arquivo >> lado3;
                                area= 2*lado1*lado2+2*lado1*lado3+2*lado2*lado3;
                                volume= lado1*lado2*lado3;
                                
                                cout <<objeto<<endl;
                                cout <<"Área:"<<area<<endl;
                                cout <<"Volume:"<<volume<<endl;
                            }else
                                if(objeto == "Cilindro"){
                                    arquivo >> raio;
                                    arquivo >> altura;
                                    area = 2*3.14*raio*altura+2*3.14*raio*raio;
                                    volume = 3.14*raio*raio*altura;
                                    
                                    cout <<objeto<<endl;
                                    cout <<"Área:"<<area<<endl;
                                    cout <<"Volume:"<<volume<<endl;
                                }else
                                    if(objeto == "Cone"){
                                        arquivo >> raio;
                                        arquivo >> altura;
                                        geratriz = raio*raio+ altura*altura;
                                        geratriz = sqrt(geratriz);
                                        area = 3.14*raio*raio+3.14*raio*geratriz;
                                        volume = 3.14*raio*raio*altura/3;
                                        
                                        cout <<objeto<<endl;
                                        cout <<"Área:"<<area<<endl;
                                        cout <<"Volume:"<<volume<<endl;
                                    }else
                                        if(objeto == "Triângulo"){
                                            arquivo >> lado;
                                            arquivo >> altura;
                                            area = lado*altura/2;
                                            
                                            cout <<objeto<<endl;
                                            cout <<"Área:"<<area<<endl;
                                            
                                        }
        
         arquivo >> objeto;        
    }

    
    return 0;
    
}

