/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Projeto para calcular a media da altura de 1000 pessoas geradas aleatóriamente
 * Author: Luís Felipe Barbosa Leite 2024.1.08.018
 *
 * Created on 26 de março de 2024, 17:01
 */

#include <cstdlib>
#include <time.h>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int i = 0;
    float altura, soma = 0, media, porcentagemmaior, alturamaxima = 0, alturaminima = 2.3, alturamaior = 0;
    
    srand(time(NULL));
    
    while(i < 1000){
        altura=15+rand()%9;
        altura=altura/10;
        cout<<"Altura gerada:"<<altura<<" metros"<<endl;
        i=i+1;
        soma=soma+altura;
        if(alturamaxima < altura){
            alturamaxima = altura;
        }
        if(alturaminima > altura){
            alturaminima=altura;
        }
        if(altura > 2.0) 
            alturamaior= alturamaior+1;
    }
   
    media=soma/1000;
    porcentagemmaior=alturamaior/100;
    
    cout<<"\nA média das alturas é "<<media<<" metros"<<endl;
    cout<<"A maior altura é "<<alturamaxima<<" metros"<<endl;
    cout<<"A menor altura é "<<alturaminima<<" metros"<<endl;
    cout<<"A porcentagem de pessoas com altura maior que 2.0 metros é "<<porcentagemmaior<<"%"<<endl;
    return 0;
    
}

