/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   trabalho4(uso de vetor) ( não consegui realizar dois tópicos do trabalho)
 * Author:Luís Felipe Barbosa Leite  2024.1.08.018
 *
 * Created on 9 de abril de 2024, 17:02
 */

#include <cstdlib>
#include <time.h>
#include <iostream>
#include <cmath>
#include <stdio.h>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int i=0, j, c, opcao, numero, intervalome, intervaloma, soma=0;
    float vetor[1000];
    
    srand(time(NULL));
    
    while(i<1000){
    vetor[i]=100+rand()%101;
    cout<<"Número gerado:"<<vetor[i]<<endl;
    i++;
    }
    
    do{
        cout<<"Selecione uma opção:"<<endl<<" 1-Informar se um valor existe no vetor e sua posição\n 2-contar quantas vezes um valor aperece num vetor,e quias as suas posições\n 3-Contar quantas vezes os valores de um intervalo aparecem no vetor\n 4-Inverter os valores do vetor 0- Encerrar\n";
        cin>>opcao;
        
        switch(opcao){
            
            case 1: 
                cout<<"Digite o numero a ser procurado: ";
                cin>>numero;
                for (i=0; i<1000; i++){
                    if(vetor[i] == numero){
                        cout<<"O número "<<numero<<" esta presente.\n";
                        cout<<"na posição:"<<i<<endl<<endl;
                break;
                     }
                }
            break;
            
            case 2:
                cout<<"Digite o numero a ser procurado: ";
                cin>>numero;
                 cout<<"O número "<<numero<<" esta presente nos seguites vetores:\n";    
                for(i=0; i<1000; i++){
                    if(vetor[i] == numero){
                       cout<<"vetor "<<i<<endl;   
                    }   
                }
                 break;
            
            case 3: 
                cout<<"Digite o valor mínimo de um vetor que começa o intervalo desejado:";
                cin>>intervalome;
                cout<<"Digite o valor máximo de um vetor que termina o intervalo desejado:";
                cin>>intervaloma;
                for(i=0; i<1000; i++){
                    if(intervalome<vetor[i] && vetor[i]<intervaloma){
                        soma=soma+1;
                    }
                }
                cout<<"Existe "<<soma<<" vetores dentro do intervalo."<<endl<<endl;
            break;
            
            case 4: 
                i=0;
                j=999;
                while(i<500){
                    c=vetor[i];
                    vetor[i]=vetor[j];
                    vetor[j]=c;
                    j--;
                    i++;
                } 
                j=999;
                for(i=0; i<1000; i++){
                    cout<<"O número do vetor é "<<vetor[j]<<" e o seu inverso é"<<vetor[i]<<endl;
                    j--;
                }
             
                break;
            
            case 0: 
                cout<<"Encerrado";
            break;
            
            default: cout<<"Opção Inválida.\n\n";
            }
        }while(opcao != 0);
        
        
        
        
        
        
    
    
    
    
    
    return 0;
}

