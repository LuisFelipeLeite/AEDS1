/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   trabahlo de carros 
 * Author: Luís Felipe Barbosa Leite 2024.1.08.018
 *
 * Created on 17 de maio de 2024, 13:38
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
#include <time.h>
#include <cmath>

using namespace std;

/*
 * 
 */
const int TAM=100;
typedef struct{
    string modelo;
    string marca;
    string tipo;
    string ano;
    float km;
    string potencia;
    string combustivel;
    string cambio;
    string direçao;
    string cor; 
    string porta; 
    string placa;
    float valor;
    bool logico;
} Veiculo;

int main(int argc, char** argv) {

    Veiculo veiculo;
    Veiculo lista[TAM];
    int qtde=0, opcao, opcc, procura;
    string opc, ajd, placabaixo, placacaro;
    float seguro, valorcaro=0.0, taxa, prestacao, mediakm=0.0, somakm=0.0, qtdekm=0.0, valormin, valormax, valorbaixo=10000000.0, Hatch=0.0, SUV=0.0, Pick=0.0,Seda=0.0,Passeio=0.0, Van=0.0, gasolina=0.0, disel=0.0, flex=0.0, porcentagem;
    
    ifstream arquivo("lista.txt");
     if(!arquivo.is_open()){
         cout<<"Erro: arquivo não existe."<<endl;
         return 1;
        }
    arquivo>>ajd; 
    for (qtde=0; ajd!="fim"; qtde++){
    
        lista[qtde].modelo= ajd; 
        arquivo>>lista[qtde].marca;
        arquivo>>lista[qtde].tipo;
        arquivo>>lista[qtde].ano;
        arquivo>>lista[qtde].km;
        arquivo>>lista[qtde].potencia;
        arquivo>>lista[qtde].combustivel;
        arquivo>>lista[qtde].cambio;
        arquivo>>lista[qtde].direçao;
        arquivo>>lista[qtde].cor;
        arquivo>>lista[qtde].porta;
        arquivo>>lista[qtde].placa;
        arquivo>>lista[qtde].valor;
        lista[qtde].logico= true;
        arquivo>>ajd;
        
        
    }arquivo.close();
    
    do{
        cout<<"\t Escolnha uma opção\n 1-Adicionar um novo veículo\n 2-buscar um veículo pela placa, com opção de exclusão da lista\n 3-Buscar veículos pelo tipo\n 4-Buscar veículos pelo câmbio\n 5-Buscar veículos por faixa de preço\n 6-top\n 0-Encerrar "<<endl<<"Selecione:"; 
        cin>>opcao;
        switch(opcao){
            
            case 1:                     
                for(int i=0; i<=TAM; i++){               //adiciona o novo veículo sem ultrapassar o limite. É adicionado no final da lista ou no lugar de um veículo deletado devido ao "if"          
                    if(lista[i].logico==false){
                        procura=i;
                        break;
                   }
                }
                cout<<"Modelo: ";
                cin>>lista[procura].modelo;
                cout<<"Marca: ";
                cin>>lista[procura].marca;
                cout<<"Tipo: ";
                cin>>lista[procura].tipo;
                cout<<"Ano: ";
                cin>>lista[procura].ano;
                cout<<"km rodados: ";
                cin>>lista[procura].km;
                cout<<"Potência do motor: ";
                cin>>lista[procura].potencia;
                cout<<"Tipo de combustível: ";
                cin>>lista[procura].combustivel;
                cout<<"Câmbio: ";
                cin>>lista[procura].cambio;
                cout<<"Direção : ";
                cin>>lista[procura].direçao;
                cout<<"Cor : ";
                cin>>lista[procura].cor;
                cout<<"Quantidade de portas : ";
                cin>>lista[procura].porta;
                cout<<"Placa : ";
                cin>>lista[procura].placa;
                cout<<"Valor : ";
                cin>>lista[procura].valor;
                lista[procura].logico=true;  
                qtde++;
                break;
                
            case 2:
                cout<<"Placa do veículo para ser procurada: ";      // O veículo vai ser procurado pela placa e se for escolido exclui-lo sua variavel lógica vai ser transformada em falsa, fazendo ela não ser escrita na lista novamente ou ser substituido por outro veículo.
                cin>>opc;
                for(int i=0; i<= qtde; i++){                      
                    if(lista[i].placa ==opc && lista[i].logico==true){
                        cout<<"Modelo: "<<lista[i].modelo<<endl;
                        cout<<"Marca: "<<lista[i].marca<<endl;
                        cout<<"Tipo: "<<lista[i].tipo<<endl;
                        cout<<"Ano: "<<lista[i].ano<<endl; 
                        cout<<"km rodados : "<<lista[i].km<<endl;
                        cout<<"Potência do motor: "<<lista[i].potencia<<endl;
                        cout<<"Tipo de combustível: "<<lista[i].combustivel<<endl;
                        cout<<"Câmbio: "<<lista[i].cambio<<endl;
                        cout<<"Direção: "<<lista[i].direçao<<endl;
                        cout<<"Cor: "<<lista[i].cor<<endl;
                        cout<<"Quantidade de portas: "<<lista[i].porta<<endl;
                        cout<<"Placa: "<<lista[i].placa<<endl;
                        cout<<"Valor: "<<lista[i].valor<<endl;  
                        cout<<"Deseja excluir o veículo?\n(1-Sim/2-Não)";
                        cin>>opcc;
                        if(opcc == 1){
                            lista[i].logico=false;
                            qtde--;
                            cout<<"Veículo excluido."<<endl<<endl;
                        }       
                    }   
                }
                break;
                
            case 3:
                cout<<"Tipo dos veículos para ser procurada: ";
                cin>>opc;
                for(int i=0; i<= qtde; i++){                               //Vai procurar veículos do tipo escolido, como o tipo pode repitir, pode aparecer mais de um veículo.
                    if(lista[i].tipo ==opc && lista[i].logico==true){
                        cout<<"Modelo: "<<lista[i].modelo<<endl;
                        cout<<"Marca: "<<lista[i].marca<<endl;
                        cout<<"Tipo: "<<lista[i].tipo<<endl;
                        cout<<"Ano: "<<lista[i].ano<<endl;
                        cout<<"km rodados : "<<lista[i].km<<endl;
                        cout<<"Potência do motor: "<<lista[i].potencia<<endl;
                        cout<<"Tipo de combustível: "<<lista[i].combustivel<<endl;
                        cout<<"Câmbio: "<<lista[i].cambio<<endl;
                        cout<<"Direção: "<<lista[i].direçao<<endl;
                        cout<<"Cor: "<<lista[i].cor<<endl;
                        cout<<"Quantidade de portas: "<<lista[i].porta<<endl;
                        cout<<"Placa: "<<lista[i].placa<<endl;
                        cout<<"Valor: "<<lista[i].valor<<endl<<"\n";  
                        
                    }       
                }   

                break; 
                
            case 4:
                    cout<<"Cambio dos veículos para ser procurada: ";
                 cin>>opc;
                for(int i=0; i<= qtde; i++){                                //Vai procurar veículos do cambio escolido, como o tipo pode repitir, pode aparecer mais de um veículo.
                    if(lista[i].cambio==opc && lista[i].logico==true){
                        cout<<"Modelo: "<<lista[i].modelo<<endl;
                        cout<<"Marca: "<<lista[i].marca<<endl;
                        cout<<"Tipo: "<<lista[i].tipo<<endl;
                        cout<<"Ano: "<<lista[i].ano<<endl;
                        cout<<"km rodados : "<<lista[i].km<<endl;
                        cout<<"Potência do motor: "<<lista[i].potencia<<endl;
                        cout<<"Tipo de combustível: "<<lista[i].combustivel<<endl;
                        cout<<"Câmbio: "<<lista[i].cambio<<endl; 
                        cout<<"Direção: "<<lista[i].direçao<<endl;
                        cout<<"Cor: "<<lista[i].cor<<endl;
                        cout<<"Quantidade de portas: "<<lista[i].porta<<endl; 
                        cout<<"Placa: "<<lista[i].placa<<endl; 
                        cout<<"Valor: "<<lista[i].valor<<endl<<"\n";  
                        
                    }       
                }   

                break;
                
            case 5:
                cout<<"Digite o valor mínimo dos veículos: ";   //vai se escoler um valor minimo e maximo e logo após delimitar a escrita dos veículos entre essa faixa de preço.
                cin>>valormin;
                cout<<"Digite o valor máximo dos veículos: ";
                cin>>valormax;
                for(int i=0; i<=qtde; i++){
                    if((lista[i].valor >= valormin && lista[i].valor <= valormax) && lista[i].logico == true){
                        cout<<"Modelo: "<<lista[i].modelo<<endl;
                        cout<<"Marca: "<<lista[i].marca<<endl;
                        cout<<"Tipo: "<<lista[i].tipo<<endl;
                        cout<<"Ano: "<<lista[i].ano<<endl; 
                        cout<<"km rodados : "<<lista[i].km<<endl;
                        cout<<"Potência do motor: "<<lista[i].potencia<<endl;
                        cout<<"Tipo de combustível: "<<lista[i].combustivel<<endl;
                        cout<<"Câmbio: "<<lista[i].cambio<<endl;
                        cout<<"Direção: "<<lista[i].direçao<<endl;
                        cout<<"Cor: "<<lista[i].cor<<endl;
                        cout<<"Quantidade de portas: "<<lista[i].porta<<endl;
                        cout<<"Placa: "<<lista[i].placa<<endl;
                        cout<<"Valor: "<<lista[i].valor<<endl<<endl;
                        
                    }
                    
                }
                break;
                
            case 6:
                for(int i=0; i<=qtde; i++){             //Faz a contagem da quantidade de veículos de cada tipo e o tipo de combustível.
                    if(lista[i].tipo=="Hatch"){
                        Hatch=Hatch+1;
                    }else
                        if(lista[i].tipo=="SUV"){
                            SUV=SUV+1;
                        }else
                            if(lista[i].tipo=="Pick-up"){
                                Pick=Pick+1;
                            }else
                                if(lista[i].tipo=="Sedã"){
                                    Seda=Seda+1;
                                }else
                                    if(lista[i].tipo=="Passeio"){
                                        Passeio=Passeio+1;
                                    }else
                                        if(lista[i].tipo=="Van"){
                                            Van=Van+1;
                                        }
                    if(lista[i].combustivel=="Flex"){
                        flex=flex+1;
                    }else
                        if(lista[i].combustivel=="Gasolina"){
                            gasolina=gasolina+1;
                        }else
                            if(lista[i].combustivel=="Diesel"){
                                disel=disel+1;
                            }
                    if(lista[i].potencia=="1.0"){       //Delimita a procura de veículos 1.0 e procura a placa e o valor do mais barato
                        if(lista[i].valor<valorbaixo){
                            valorbaixo=lista[i].valor; 
                            placabaixo=lista[i].placa;     
                        }
                    }     
                    if(lista[i].ano<="2019"){
                        somakm=somakm+lista[i].km;
                        qtdekm=qtdekm+1;
                    }   
                    if(lista[i].cambio=="Automático" && lista[i].direçao=="Hidráulica"){
                        if(lista[i].valor>valorcaro){
                            valorcaro=lista[i].valor;
                            placacaro=lista[i].placa;
                        }
                    }

                }
                

                porcentagem=(Hatch/qtde)*100;                           //Calcula a porcentagem dos tipos e tipos de combustíveis dos veículos 
                cout<<porcentagem<<"% de veículos tipo hatch"<<endl;
                porcentagem=(SUV/qtde)*100;
                cout<<porcentagem<<"% de veículos tipo SUV"<<endl;
                porcentagem=(Pick/qtde)*100;
                cout<<porcentagem<<"% de veículos tipo pick-up"<<endl;
                porcentagem=(Seda/qtde)*100;
                cout<<porcentagem<<"% de veículos tipo sedã"<<endl;
                porcentagem=(Passeio/qtde)*100;
                cout<<porcentagem<<"% de veículos tipo passeio"<<endl;
                porcentagem=(Van/qtde)*100;
                cout<<porcentagem<<"% de veículos tipo van"<<endl<<endl;;
                porcentagem=(flex/qtde)*100;
                cout<<porcentagem<<"% de Veículos com combustível flex"<<endl;
                porcentagem=(gasolina/qtde)*100;
                cout<<porcentagem<<"% de veículos com combustível à gasolina"<<endl;
                porcentagem=(disel/qtde)*100;
                cout<<porcentagem<<"% de veículos com combustível à diesel"<<endl<<endl;
                taxa=pow(1.0117, 60);
                prestacao=(valorbaixo*taxa*0.0117)/(taxa-1);
                cout<<"O veículo 1.0 mais barato possui a placa "<<placabaixo<<" e custa R$"<<valorbaixo<<".00"<<endl;
                cout<<"O valor da prestação do financiamento em 60 meses desse veículo é de R$"<<prestacao<<endl<<endl;
                if(valorcaro<60000){
                   seguro=valorcaro*0.04; 
                }else
                    if(valorcaro<120000){
                        seguro=valorcaro*0.06; 
                }else
                    if(valorcaro>150000){
                        seguro=valorcaro*0.085; 
                }
                cout<<"O veículo mais caro com direção hidráulica e câmbio automático tem a placa "<<placacaro<<" e custa R$"<<valorcaro<<".00"<<endl;
                cout<<"o valor do seguro desse carro é R$"<<seguro<<endl<<endl;
                mediakm=(somakm/qtdekm);
                cout<<"A lista contem "<<qtdekm<<" veículos com mais de 5 anos, e a média de quilometros rodados deles é "<<mediakm<<"quilômetros"<<endl<<endl;
                
                
                break;
                
                case 0: 
                break;
            
          default: cout<<"Opção Inválida.\n";  
        }
    }while(opcao != 0);
    
    
    
  ofstream arquivo2("lista.txt");
    if(!arquivo2.is_open()){
         cout<<"Erro: arquivo não existe."<<endl;
         return 1;
        }
     
    for (int i=0; i<=qtde; i++){
        if(lista[i].logico== true){
            arquivo2<<lista[i].modelo<<" ";
            arquivo2<<lista[i].marca<<" ";
            arquivo2<<lista[i].tipo<<" ";
            arquivo2<<lista[i].ano<<" ";
            arquivo2<<lista[i].km<<" ";
            arquivo2<<lista[i].potencia<<" ";
            arquivo2<<lista[i].combustivel<<" ";
            arquivo2<<lista[i].cambio<<" ";
            arquivo2<<lista[i].direçao<<" ";
            arquivo2<<lista[i].cor<<" ";
            arquivo2<<lista[i].porta<<" ";
            arquivo2<<lista[i].placa<<" ";
            arquivo2<<lista[i].valor<<" \n";
        }  
    } arquivo2<<"fim";

    
  
  
    return 0;
}

