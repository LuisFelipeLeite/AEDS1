#include "matriz.h"
#include <iostream>
using namespace std;

//Gera a matriz transposta.
void transposta(int MAT[TAM][TAM], int trans[TAM][TAM]){
    for(int i=0; i<TAM; i++){
        for(int j=0; j<TAM; j++){
            trans[j][i]=MAT[i][j];

        }
    }
}
//Soma o valor de duas matrizes.
void somadematriz(int MAT[TAM][TAM], int MAT2[TAM][TAM], int soma[TAM][TAM]){
    for(int i=0; i<TAM; i++){
        for(int j=0; j<TAM; j++){
            soma[i][j]=MAT[i][j]+MAT2[i][j];

        }
    }
}
//Multiplica o valor de duas matrizes.
void multdematriz(int MAT[TAM][TAM], int MAT2[TAM][TAM], int mult[TAM][TAM]){
    for(int i=0; i<TAM; i++){
        for(int j=0; j<TAM; j++){
            mult[i][j]=0;
            for(int z=0; z<TAM; z++){
                mult[i][j]=mult[i][j]+(MAT[i][z]*MAT2[z][j]);
            }
        }
    }
}
//Calcula a mÃ©dia de uma matriz.
int mediadematriz(int MAT[TAM][TAM]){
    int media=0;
    for(int i=0; i<TAM; i++){
        for(int j=0; j<TAM; j++){
            media=media+MAT[i][j];
        }
    }
    return media/(TAM*TAM);
}
