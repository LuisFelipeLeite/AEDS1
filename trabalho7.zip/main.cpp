/* 
 * File:   Agenda de amigos.
 * Author: Luis Felipe Barbosa Leite 2024.1.08.018
 * Trabalho para demostrar a ultilização de matriz e função 
 * 
 */
#include <stdio.h>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "matriz.h"

using namespace std;
//Escreve no terminal uma matriz.
void escrita(int MAT[TAM][TAM]){
     for(int i=0; i<TAM; i++) {
        for (int j=0; j<TAM; j++) {
            cout<<MAT[i][j]<<" ";
        }
        cout<<endl;
    }
}
//Gera valores aleatorios para uma matriz.
void gerador(int MAt[TAM][TAM]){
    srand(time(NULL));
    for(int i=0; i<TAM; i++) {
        for (int j=0; j<TAM; j++) {
            MAt[i][j]=rand()%10;
        }
    }
}

int main(){

    int mat1[TAM][TAM];
    int mat2[TAM][TAM]={
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    int trans[TAM][TAM];
    int soma[TAM][TAM];
    int mult[TAM][TAM];
    int media;
    //Gera e escreve os valores da Matriz 1
    gerador(mat1);
    cout<<"Matriz 1:"<<endl;
    escrita(mat1);
    cout<<endl;

    //Escre os valores da Matriz 2.
    cout<<"Matriz 2:"<<endl;
    escrita(mat2);
    cout<<endl;

    //Calcula e escreve a trasposta da Matriz 1.
    transposta(mat1,trans);
    cout<<"Transposta da Matriz 1:"<<endl;
    escrita(trans);
    cout<<endl;

    //Calcula e escreve a soma da Matriz 1 e da Matriz 2.
    somadematriz(mat1,mat2,soma);
    cout<<"Soma das matrizes:"<<endl;
    escrita(soma);
    cout<<endl;

    //Calcula e escreve a multiplicação da Matriz 1 e da Matriz 2.
    multdematriz(mat1,mat2,mult);
    cout<<"Multiplicação das matrizes:"<<endl;
    escrita(mult);
    cout<<endl;

    //Calcula e escreve a média dos valores da Matriz 1.
    media=mediadematriz(mat1);
    cout<<"A média dos valores da Matriz 1 é "<<media<<endl; 
    return 0; 
}
