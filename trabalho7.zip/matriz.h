#ifndef MATRIZ_H
#define MATRIZ_H

const int TAM=3;
void transposta(int MAT[TAM][TAM], int trans[TAM][TAM]);
void somadematriz(int MAT[TAM][TAM], int MAT2[TAM][TAM], int soma[TAM][TAM]);
void multdematriz(int MAT[TAM][TAM], int MAT2[TAM][TAM], int mult[TAM][TAM]);
int mediadematriz(int MAT[TAM][TAM]);

#endif
