/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   Agenda de amigos.
 * Author: Luis Felipe Barbosa Leite 2024.1.08.018
 *
 * Created on 29 de abril de 2024, 16:05
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
#include <time.h>
using namespace std;

/*
 * 
 */
const int TAM=101;
typedef struct{
    string nome;
    string celular;
    string cidade;
    string email; 
    bool logico;
} Pessoa;

int main(int argc, char** argv) {

    Pessoa amigo;
    Pessoa agenda[TAM];
    int qtde=0, opcao;
    string opc;
    
    ifstream arquivo("entrada.txt");
     if(!arquivo.is_open()){
         cout<<"Erro: arquivo não existe."<<endl;
         return 1;
        }
    arquivo>>agenda[0].nome; 
    for (qtde=0; agenda[qtde].nome!="fim"; qtde++){
    
        arquivo>>agenda[qtde].celular;
        arquivo>>agenda[qtde].cidade;
        arquivo>>agenda[qtde].email;
        arquivo>>agenda[qtde+1].nome;
        agenda[qtde].logico= true;
    }arquivo.close();
    
    do{
        cout<<" 1-Adicionar um novo amigo\n 2-Remover um amigo\n 3-Buscar um amigo\n 0-Encerrar "<<endl<<"Selecione:"; 
        cin>>opcao;
        switch(opcao){
            
            case 1:
                cout<<"Nome: "<<endl;
                cin>>agenda[qtde].nome;
                cout<<"Celular: "<<endl;
                cin>>agenda[qtde].celular;
                cout<<"Cidade: "<<endl;
                cin>>agenda[qtde].cidade;
                cout<<"Email: "<<endl;
                cin>>agenda[qtde].email;
                agenda[qtde].logico=true;
                agenda[qtde+1].nome="fim";
                qtde++;
                break;
            case 2:
                cout<<"Amigo para ser excluido: "<<endl;
                cin>>opc;
                cout<<"Amigo Excluido"<<endl;
                for(int i=0; i<=qtde; i++){
                   if(agenda[i].nome==opc){
                      agenda[i].logico=false; 
                   }
                }
                break;
            case 3:
                cout<<"Amigo para ser procurado: ";
                cin>>opc;
                for(int i=0; i<= qtde; i++){
                    if(agenda[i].nome==opc){
                        cout<<endl<<"Nome: "<<agenda[i].nome<<endl;
                        cout<<"Celular: "<<agenda[i].celular<<endl;
                        cout<<"Cidade: "<<agenda[i].cidade<<endl;
                        cout<<"Email: "<<agenda[i].email<<endl<<endl;  
                    }
                        
                }
                break;
            case 0: 
                break;
            
          default: cout<<"Opção Inválida.\n";  
        }
    }while(opcao != 0);
    
    
    
  ofstream arquivo2("entrada.txt");
    if(!arquivo2.is_open()){
         cout<<"Erro: arquivo não existe."<<endl;
         return 1;
        }
     
    for (qtde=0; agenda[qtde].nome!="fim"; qtde++){
        if(agenda[qtde].logico== true){
            arquivo2<<agenda[qtde].nome<<"\t";
            arquivo2<<agenda[qtde].celular<<"\t";
            arquivo2<<agenda[qtde].cidade<<"\t";
            arquivo2<<agenda[qtde].email<<"\t\n"; 
        }  
    } arquivo2<<"fim";

    
  
  
    return 0;
}

